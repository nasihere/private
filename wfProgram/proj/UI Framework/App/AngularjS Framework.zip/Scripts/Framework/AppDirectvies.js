﻿app.directive('appInput', function() {
    var directive = {};

    directive.restrict = 'E';

    directive.template = [
        '<single-calandar ng-if="option.type == \'calendar\'" prop="option"></single-calandar>' +
        '<single-select ng-if="option.type == \'dropdown\'" mapmodel="option.model" prop="option"></single-select>' +
        '<single-checkbox ng-if="option.type == \'chk\'" prop ="option"></single-checkbox>' +
        '<single-radio ng-if="option.type == \'rdo\'" prop ="option"></single-radio>' +
        '<single-button ng-if="option.type == \'button\'"  prop="option" ></single-button>' +
        '<single-text ng-if="option.type == \'text\'" mapmodel="option.model" prop="option"></single-text>'
        
    ].join('');

    directive.scope = {
        option: '='
    };

    directive.link = function (scope, element, attrs) {
    };

    return directive;
});
app.directive('singleSelect', function () {
    var directive = {};

    directive.restrict = 'E';
   
    directive.template = [
        '<select ng-model="mapmodel" valid="{{prop.valid}}" class="form-control m-b">',
        '<option value="{{value.value}}" ng-repeat="value in prop.values">{{value.label}}</option>',
        '</select>'
    ].join('');

    directive.scope = {
        mapmodel: '=',
        prop: '='
    };

    directive.link = function (scope, element, attrs) {
    };

    return directive;
});
app.directive('singleText', function () {
    var directive = {};

    directive.restrict = 'E';
    
    directive.template = [
        '<input type="text" ng-model="mapmodel" valid={{prop.valid}}  class="form-control" value="{{prop.text}}" ></input>'
    ].join('');

    directive.scope = {
        mapmodel: '=',
        prop:'='
    };

    directive.link = function (scope, element, attrs) {
    };

    return directive;
});
app.directive('singleCalandar', function () {
    var directive = {};

    directive.restrict = 'E';

    directive.template = [
        '<input type="text"  valid="{{prop.valid}}"  class="form-control datecomp" value="{{prop.text}}" ></input>'
    ].join('');

    directive.scope = {
        mapmodel: '=',
        prop: '='
    };

    directive.link = function (scope, element, attrs) {
    };

    return directive;
});

app.directive('singleRadio', function () {
    var directive = {};

    directive.restrict = 'E';

    directive.template = [
        ' <div class="radio i-checks"><label> <input type="radio"  checked="{{prop.optcheck}}" value="{{prop.optvalue}}" name="a"> <i></i> {{prop.complabel}} </label></div>'
    ].join('');

    directive.scope = {
       prop: '='
    };

    directive.link = function (scope, element, attrs) {
    };

    return directive;
});
app.directive('singleCheckbox', function () {
    var directive = {};

    directive.restrict = 'E';

    directive.template = [
        '<div class="checkbox i-checks"><label> <input type="checkbox" value=""  checked="{{prop.chkvalue}}"> <i></i> {{prop.complabel}} </label></div>'
    ].join('');

    directive.scope = {
        prop:'='
    };

    directive.link = function (scope, element, attrs) {
    };

    return directive;
});

app.directive('singleButton', function ($compile) {
    var obj = '<a ng-click="prop.click(prop.clickparam)" ng-blur="prop.blur(prop.blurparam)"  class="btn btn-sm btn-primary {{prop.cls}}"><strong>{{prop.complabel}}</strong></a>';
  var directiveObj =  {
        restrict: 'E',
        replace: true,
        scope: {
            prop: '=',
            value: '=',
            cls: '='
          
            
        },
        template: obj
    };
    return directiveObj;

});
app.directive('jform', function () {
    return {
         scope: {
            form: "=",
            space: "@",
            template: "@"

        },
         template: '<ng-include src="getTemplateUrl()"/>',
         controller: function ($scope) {
             //function used on the ng-include to resolve the template
             $scope.getTemplateUrl = function() {
                 //basic handling
                 if ($scope.template == "HorizontalForm")
                     return "./Shared/Template/HorizontalForm.html ";
                 else if ($scope.template == "CardTemplate")
                     return "./Shared/Template/CardTemplate.html";
                 else if ($scope.template == "TabTemplate")
                     return "./Shared/Template/TabTemplate.html";

                
             };
         }
    };
});
app.directive('jmultiform', function () {
    return {
        scope: {
            attr: "=",
            template: "@",
            jform: "="

        },
        template: '<ng-include src="getTemplateUrl()"/>',
        controller: function ($scope) {
            //function used on the ng-include to resolve the template
            $scope.getTemplateUrl = function () {
                //basic handling
              
                 if ($scope.template == "TabTemplate")
                    return "./Shared/Template/TabTemplate.html";
                 else if ($scope.template == "CardTemplate")
                     return "./Shared/Template/CardTemplate.html";
                 else if ($scope.template == "HorizontalForm")
                     return "./Shared/Template/HorizontalForm.html";
                 else if ($scope.template == "ModalTemplate")
                     return "./Shared/Template/ModalTemplate.html";


            };
        }
    };
});


/* will remove this directive and call it on StateProvider service */
app.directive('componentbind', function () {
    return {
        
       
        controller: function ($scope) {
             setTimeout(function() { init(); }, 500);
        }
    };
});

﻿var tempRepeat = [

  { label: 'Select', value: "" },
  { label: 'John', value: 25 },
  { label: 'Jessie', value: 30 },
  { label: 'Johanna', value: 28 },
  { label: 'Joy', value: 15 },
  { label: 'Mary', value: 28 },
  { label: 'Peter', value: 95 },
  { label: 'Sebastian', value: 50 },
  { label: 'Erika', value: 27 },
  { label: 'Patrick', value: 40 },
  { label: 'Samantha', value: 60 }
]





var jColSize = [
    
        { label: 'Free Size', value: '' },
        { label: 'Size 1', value: 'col-sm-1' },
        { label: 'Size 2', value: 'col-sm-2' },
         { label: 'Size 3', value: 'col-sm-3' },
    { label: 'Size 4', value: 'col-sm-4' },
        { label: 'Size 5', value: 'col-sm-5' },
         { label: 'Size 6', value: 'col-sm-6' },
    { label: 'Size 7', value: 'col-sm-7' },
        { label: 'Size 8', value: 'col-sm-8' },
         { label: 'Size 9', value: 'col-sm-9' },
    { label: 'Size 10', value: 'col-sm-10' },
        { label: 'Size 11', value: 'col-sm-11' },
         { label: 'Size 12', value: 'col-sm-12' },
    { label: 'Pull Right', value: 'pull-right' },
        { label: 'pull left', value: 'pull-left' }
]
var jLayoutSize = [

        { label: 'Single Cols', value: 'col-sm-12' },
        { label: 'Two Cols', value: 'col-sm-6' },
        { label: 'Multi Cols', value: 'col-sm-3' },
        
        
]
jLayoutSize = jLayoutSize.concat(jColSize);









var jMenu = [
        { title: 'Reset', href: 'somevalue' },
        { title: 'Delete', href: 'myvalue' },
         { title: 'Your Menu', href: 'myvalue' }
]










































var jFieldsForm4 = {
    data: [
        { phone: "(123) 456-7890", address: "795 Folsom Ave ", company: "Twitter, In", location: "Riviera State 456/4566", designation: "Graphics designer", src: 'a2', cls: "img-circle m-t-xs img-responsive" },
        
         { phone: "(345) 567-3456", address: "Harrison,\n Santa Clara", company: "Yahoo, Inc", location: "Van Nuys State 32/106", designation: "Software designer", src: 'a4', cls: "img-circle m-t-xs img-responsive" },
        
         { phone: "(567) 456-7890", address: "1220 Concord Ave\n Concord", company: "Microsoft", location: "Mark Street 65/345", designation: "Marketing", src: 'a3', cls: "img-circle m-t-xs img-responsive" },
        
        { phone: "(345) 567-3456", address: "1239 Harrison St, \n Santa Clara", company: "Yahoo, Inc", location: "Van Nuys State 32/106", designation: "Software designer", src: 'a5', cls: "img-circle m-t-xs img-responsive" },
        

         { phone: "(567) 456-7890", address: "1220 Concord Ave\n Concord", company: "Microsoft", location: "Mark Street 65/345", designation: "Marketing", src: 'a1', cls: "img-circle m-t-xs img-responsive" },
        
         { phone: "(123) 456-7890", address: "795 Folsom Ave, Suite 600\n San Francisco", company: "Twitter, In", location: "Riviera State 456/4566", designation: "Graphics designer", src: 'a7', cls: "img-circle m-t-xs img-responsive" },

    ]

};
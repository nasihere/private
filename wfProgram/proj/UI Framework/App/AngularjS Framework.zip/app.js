﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="appjs" company="Wells Fargo">
//  Wells Fargo Consumer Lending Sales Presentation
//  Copyright ©2010 - 2020 Wells Fargo. All rights reserved.
//  This Software is the confidential and proprietary information of Wells Fargo.
//  Usage governed by the license agreement with Wells Fargo.
// </copyright>
// <summary>
//  It Start the angularjs engine to work on html
//  veryimportant call in the project to begin
//	
// </summary>
// <remarks></remarks>
// <author></author>
// <version>1.0</version>
// <revision></revision>
// <includesource>yes</includesource>
// <todo></todo>
// <developer>Nasir Sayed</developer>
// --------------------------------------------------------------------------------------------------------------------
var app = angular.module("service", []);
var app = angular.module("app", ['service']);

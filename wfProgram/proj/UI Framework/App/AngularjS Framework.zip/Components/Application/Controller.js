﻿app.controller("BaseController", ['$scope', function ($scope) {
    $scope.jform = TestForm;
    $scope.ChangeContoller = function() {
        $scope.jform = jForms;


    };


}]);
app.controller("ApplicationController", ['$scope', function ($scope) {
    $scope.jform = TestForm;
    
    
}]);

app.controller("CardController", ['$scope', function ($scope) {
   
}]);


app.controller("TabController", ['$scope', function ($scope) {
    $scope.parent = {};
    $scope.parent.template = "TabTemplate";
    $scope.parent.attr = {};
    $scope.parent.attr.space = "col-lg-12";
    $scope.parent.attr.title = "Nasir Tab panel activity";
    $scope.parent.attr.list = [
        {
            title: "Tab 1", expanded: "true", cls: "active"
        },
        {
            title: "Tab 2",
            expanded: "false"
        },
        {
            title: "Tab 3",
            expanded: "false"
        },

    ];
    $scope.parent.attr.jform = jCards;
   
}]);

app.controller("ModalController", ['$scope', function ($scope) {
    $scope.parent = {};
    $scope.parent.template = "ModalTemplate";
    $scope.parent.attr = {};
    $scope.parent.attr.space = "col-lg-12";
    $scope.parent.attr.title = "Nasir Tab panel activity";
    $scope.parent.attr.list = [
        {
            title: "Tab 1", expanded: "true", cls: "active"
        },
        {
            title: "Tab 2",
            expanded: "false"
        },
        {
            title: "Tab 3",
            expanded: "false"
        },

    ];
    $scope.parent.attr.jform = jCards;
}]);


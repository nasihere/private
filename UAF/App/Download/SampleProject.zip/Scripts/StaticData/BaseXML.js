﻿var Root= "";
var AppRoot = "";
var AppError = "";
var angB;
var angA;
var applicationMethod;
var coApplicationMethod;
var nW = {
    l: "",
    e: "",
    w: "",
    s: ""
}

